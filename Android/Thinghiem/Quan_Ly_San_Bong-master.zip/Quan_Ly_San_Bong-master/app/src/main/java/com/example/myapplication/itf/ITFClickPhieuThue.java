package com.example.myapplication.itf;

import com.example.myapplication.entity.PhieuThue;

public interface ITFClickPhieuThue {
    void OnClick(PhieuThue phieuThue);
}
