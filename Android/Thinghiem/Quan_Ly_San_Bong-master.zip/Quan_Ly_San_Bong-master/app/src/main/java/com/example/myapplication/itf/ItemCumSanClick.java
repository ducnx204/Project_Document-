package com.example.myapplication.itf;

import com.example.myapplication.entity.CumSan;

public interface ItemCumSanClick {
    void onItemClick(CumSan cumSan, String typeKey);
}
