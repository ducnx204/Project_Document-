package com.example.mob2041_duanmauandroid.LOPPRODUCT;

public class Top {
  public   String tensach;
  public   int soluong;


}
