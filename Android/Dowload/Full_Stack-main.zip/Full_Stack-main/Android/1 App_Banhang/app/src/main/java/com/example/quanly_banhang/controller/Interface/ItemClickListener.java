package com.example.quanly_banhang.controller.Interface;

import android.view.View;

public interface ItemClickListener {
    void onClick(View view , int pos, boolean isLongclick);

}
