package com.example.quanly_banhang.controller.model.Evenrbus;

import com.example.quanly_banhang.controller.model.DonHang;

public class DonhangEvenrbus {
    DonHang donHang;

    public DonhangEvenrbus(DonHang donHang) {
        this.donHang = donHang;
    }

    public DonHang getDonHang() {
        return donHang;
    }

    public void setDonHang(DonHang donHang) {
        this.donHang = donHang;
    }
}
