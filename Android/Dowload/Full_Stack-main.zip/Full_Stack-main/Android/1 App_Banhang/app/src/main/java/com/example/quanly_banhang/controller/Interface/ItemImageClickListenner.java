package com.example.quanly_banhang.controller.Interface;

import android.view.View;

public interface ItemImageClickListenner {
    void onImageClick(View view,int pos,int giatri);

}
