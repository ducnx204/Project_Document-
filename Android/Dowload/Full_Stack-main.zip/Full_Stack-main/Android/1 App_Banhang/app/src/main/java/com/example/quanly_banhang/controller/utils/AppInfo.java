package com.example.quanly_banhang.controller.utils;

public class AppInfo {
    public static final int APP_ID = 2554;
    public static final String MAC_KEY = "sdngKKJmqEMzvh5QQcdD2A9XBSKUNaYn";
    public static final String URL_CREATE_ORDER = "https://sb-openapi.zalopay.vn/v2/create";
}
