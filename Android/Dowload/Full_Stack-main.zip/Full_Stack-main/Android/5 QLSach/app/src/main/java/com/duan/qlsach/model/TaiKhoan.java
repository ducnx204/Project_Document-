package com.duan.qlsach.model;

public class TaiKhoan {
    public String tenDangNhap;
    public String tenNguoiDung;
    public String matKhau;

    public TaiKhoan() {
    }

    public TaiKhoan(String tenDangNhap, String tenNguoiDung, String matKhau) {
        this.tenDangNhap = tenDangNhap;
        this.tenNguoiDung = tenNguoiDung;
        this.matKhau = matKhau;
    }
}
