package com.duan.qlsach.model;

public class TheLoai {
    public int maLoai;
    public String tenLoai;

    public TheLoai() {
    }

    public TheLoai(int maLoai, String tenLoai) {
        this.maLoai = maLoai;
        this.tenLoai = tenLoai;
    }
}
