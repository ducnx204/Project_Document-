package com.duan.qlsach.model;

public class KeSach {
    public int maKS;
    public String tenKS;

    public KeSach() {
    }

    public KeSach(int maKS, String tenKS) {
        this.maKS = maKS;
        this.tenKS = tenKS;
    }
}
